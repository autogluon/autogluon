```console
conda create -n ag python=3.11
conda activate ag
conda install -c conda-forge mamba
mamba install -c conda-forge autogluon 
```
