```console
pip install -U pip
pip install -U setuptools wheel
pip install autogluon --extra-index-url https://download.pytorch.org/whl/cpu
```
