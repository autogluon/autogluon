```console
# Install UV package installer (faster than pip)
pip install -U uv

# Install AutoGluon
python -m uv pip install autogluon --extra-index-url https://download.pytorch.org/whl/cpu
```
