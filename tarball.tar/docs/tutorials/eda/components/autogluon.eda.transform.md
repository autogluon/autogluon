```{eval-rst}
.. role:: hidden
    :class: hidden-section
```

# Components: transform

## autogluon.eda.analysis.transform

```{eval-rst}
.. automodule:: autogluon.eda.analysis.transform
```

```{eval-rst}
.. currentmodule:: autogluon.eda.analysis.transform
```

```{eval-rst}
.. autosummary::
    :nosignatures:

    ApplyFeatureGenerator
```

### {hidden}`ApplyFeatureGenerator`

```{eval-rst}
.. autoclass:: ApplyFeatureGenerator
   :members: init
```
