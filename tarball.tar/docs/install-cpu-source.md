```console
pip install uv
python -m uv pip install -U torch torchvision --extra-index-url https://download.pytorch.org/whl/cpu
git clone https://github.com/autogluon/autogluon
cd autogluon && ./full_install.sh
```
