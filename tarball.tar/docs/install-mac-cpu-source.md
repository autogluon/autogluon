```console
pip install -U pip
pip install -U setuptools wheel

git clone https://github.com/autogluon/autogluon
cd autogluon && ./full_install.sh
```
