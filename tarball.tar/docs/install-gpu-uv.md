```console
# Install UV package installer (faster than pip)
pip install -U uv

# Install AutoGluon with GPU support
python -m uv pip install autogluon
```
