```console
pip install -U pip
pip install -U setuptools wheel
pip install autogluon
```
