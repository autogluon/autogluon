```console
git clone https://github.com/autogluon/autogluon
cd autogluon && ./full_install.sh
```
