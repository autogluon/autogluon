function setup_mmcv {
  # Install MMEngine from git with the fix for torch 2.5
  python3 -m pip install "git+https://github.com/open-mmlab/mmengine.git@2e0ab7a92220d2f0c725798047773495d589c548"
  mim install "mmcv==2.1.0" --timeout 60
  python3 -m pip install "mmdet==3.2.0"
}
