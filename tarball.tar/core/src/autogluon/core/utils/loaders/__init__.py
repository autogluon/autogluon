from autogluon.common.loaders import load_json, load_pd, load_pkl, load_pointer, load_s3, load_str, load_zip
